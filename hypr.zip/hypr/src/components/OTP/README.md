## PROPS
1. inputCount  
## count of inputBox
## default value=> 4

2. offTintColor
## border color of unfocused box
## default value=> "#DCDCDC"

3. tintColor
## border color of focused box 
## default value=> "#3CB371"

4. defaultValue
## default value
## default value=> ""

5. inputCellLength
## max length per inputBox
## default value=> 1

6. containerStyle
## style of whole container
## default value=> {}

7. textInputStyle
## style of per inputBox
## default value=> {}
## with default styling i.e. 
textInput: {
        height: 50,
        width: 50,
        borderBottomWidth: 2,
        margin: 5,
        textAlign: "center",
        fontSize: 22,
        fontWeight: "500",
        color: "#000000",
    },

8. keyboardType
## keyboard type 
## default value=> "numeric"

9. handleTextChange
## handle the changes