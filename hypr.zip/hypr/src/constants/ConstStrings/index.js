const ConstStrings = {

}
export default ConstStrings;