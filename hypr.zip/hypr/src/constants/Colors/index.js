const Colors = {
    black: '#000000',
    white: '#fff',
    transparent: "transparent",
    primary: "rgb(244,0,146)",
    secondry: "rgb(134,24,156)",
    inputBackground: "rgb(245,245,245)",
    linkText: "rgb(75,35,162)",
    placeholder: "rgb(132,132,132)",
    color_47_44_44: "rgb(47,44,44)",
    cart_color: "rgb(255,192,65)",
    light_grey: "#E1E4E6",
};
export default Colors;