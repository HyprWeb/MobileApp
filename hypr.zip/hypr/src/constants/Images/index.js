export default {
    logo: require("../../assets/Images/Hypr_Logo.png"),
    google: require("../../assets/Images/google.png"),
    user: require("../../assets/Images/user.jpg"),
};