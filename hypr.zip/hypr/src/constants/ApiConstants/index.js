const STATUS_SUCCESS_CODE = 201;
const API_ERROR = "Something went wrong.Please try after sometimes."
export default {
    STATUS_SUCCESS_CODE,
    API_ERROR
}