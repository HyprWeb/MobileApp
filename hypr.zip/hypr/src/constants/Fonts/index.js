export default {
    K2D_Thin: "K2D-Thin",
    K2D_ExtraLight: "K2D-Extralight",
    K2D_Light: "K2D-Light",
    K2D_Medium: "K2D-Medium",
    K2D_Regular: "K2D-Regular",
    K2D_SemiBold: "K2D-Semibold",
    K2D_Bold: "K2D-Bold",
    K2D_ExtraBold: "K2D-ExtraBold",
    SF_ProText: "SFProText-Regular",
}